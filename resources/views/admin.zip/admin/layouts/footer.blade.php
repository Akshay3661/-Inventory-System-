<div id="kt_app_footer" class="app-footer">
    <!--begin::Footer container-->
    <div class="app-container container-fluid d-flex flex-column flex-md-row flex-center flex-md-stack py-3">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-semibold me-1">2023&copy;</span>
            <a href="https://keenthemes.com" target="_blank" class="text-gray-800 text-hover-primary">Keenthemes</a>
        </div>
        <!--end::Copyright-->
        <!--begin::Menu-->
        <ul class="menu menu-gray-600 menu-hover-primary fw-semibold order-1">
            <li class="menu-item">
                <a href="https://keenthemes.com" target="_blank" class="menu-link px-2">About</a>
            </li>
            <li class="menu-item">
                <a href="https://devs.keenthemes.com" target="_blank" class="menu-link px-2">Support</a>
            </li>
            <li class="menu-item">
                <a href="https://1.envato.market/EA4JP" target="_blank" class="menu-link px-2">Purchase</a>
            </li>
        </ul>
        <!--end::Menu-->
    </div>
    <!--end::Footer container-->
</div>

</div>
<!--end::Wrapper-->
</div>
<!--end::Page-->
</div>

<!--end::Modal - Invite Friend-->
<!--end::Modals-->
<!--begin::Javascript-->
<script>var hostUrl = "assets/";</script>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<!--begin::Global Javascript Bundle(mandatory for all pages)-->
<script src="{{asset('admin/dist/assets/plugins/global/plugins.bundle.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/scripts.bundle.js')}}"></script>
<!--end::Global Javascript Bundle-->
<!--begin::Vendors Javascript(used for this page only)-->
<script src="{{asset('admin/dist/assets/plugins/custom/fullcalendar/fullcalendar.bundle.js')}}"></script>
<script src="https://cdn.amcharts.com/lib/5/index.js"></script>
<script src="https://cdn.amcharts.com/lib/5/xy.js"></script>
<script src="https://cdn.amcharts.com/lib/5/percent.js"></script>
<script src="https://cdn.amcharts.com/lib/5/radar.js"></script>
<script src="https://cdn.amcharts.com/lib/5/themes/Animated.js"></script>
<script src="https://cdn.amcharts.com/lib/5/map.js"></script>
<script src="https://cdn.amcharts.com/lib/5/geodata/worldLow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/geodata/continentsLow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/geodata/usaLow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/geodata/worldTimeZonesLow.js"></script>
<script src="https://cdn.amcharts.com/lib/5/geodata/worldTimeZoneAreasLow.js"></script>
<script src="{{asset('admin/dist/assets/plugins/custom/datatables/datatables.bundle.js')}}"></script>
<!--end::Vendors Javascript-->
<!--begin::Custom Javascript(used for this page only)-->
<script src="{{asset('admin/dist/assets/js/custom/apps/ecommerce/catalog/products.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/widgets.bundle.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/custom/widgets.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/custom/apps/chat/chat.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/custom/utilities/modals/upgrade-plan.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/custom/utilities/modals/create-app.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/custom/utilities/modals/new-target.js')}}"></script>
<script src="{{asset('admin/dist/assets/js/custom/utilities/modals/users-search.js')}}"></script>

<!-- validation cdn -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js"></script>
<script type="text/javascript" src="{{asset('admin/js/validation.js')}}"></script>


<script>
       $("document").ready(function(){
        setTimeout(function(){
           $("div.alert").remove();
        }, 3000 );
    });



</script>
</body>
<!--end::Body-->
</html>
