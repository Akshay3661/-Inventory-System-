@extends('admin.layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            @if(session()->has('message'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
              {{session()->get('message')}}
             <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            @endif
            @if (Session::has('error'))
              <div class="alert alert-warning alert-dismissible fade show" role="alert">
                {{session()->get('error')}}
               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            @endif
            @if (Session::has('danger'))
              <div class="alert alert-warning alert-dismissible fade show" role="alert">
                {{session()->get('danger')}}
               <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            @endif
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home-tab-pane" type="button" role="tab" aria-controls="home-tab-pane" aria-selected="true">Update Profile</button>
                </li>
                <li class="nav-item" role="presentation">
                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile-tab-pane" type="button" role="tab" aria-controls="profile-tab-pane" aria-selected="false">Change Password</button>
                </li>
            </ul>

             {{-- {{  dd($admin)}} --}}
            <form action="{{ url('profile_update/'.$user->id) }}" method="post" enctype="multipart/form-data">
            @csrf

            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="home-tab-pane" role="tabpanel" aria-labelledby="home-tab" tabindex="0">
                    <div class="row">
                        <div class="col-sm-3 mt-3">
                            <label for="exampleFormControlInput1" class="form-label">Profile Image</label> <br>
                            {{-- <img src=" {{ asset('user_image/'.$admin->profile_image) }}" style="width: 100px;height:100px" class="rounded-circle"><br> --}}
                            <button type="button" data-bs-toggle="modal" data-bs-target="#editimgModal" class="btn edit-profile mt-2">
                                <i class="fa-regular fa-pen-to-square"></i> Edit Profile
                            </button>
                        </div>
                        <div class="col-sm-3">
                        </div>
                        <div class="col-sm-3">
                        </div>
                        <div class="col-sm-3">
                        </div>
                    </div>
                  <div class="row">
                    <div class="col-sm-3">
                        <div class="mb-3 mt-3">
                            <label for="exampleFormControlInput1" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="{{$user->name}}">
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="mb-3 mt-3">
                            <label for="exampleFormControlInput1" class="form-label">Email</label>
                            <input type="email" class="form-control" id="eamil" name="email"  value="{{$user->email}}">
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="mb-3 mt-3">
                            <label for="exampleFormControlInput1" class="form-label">Mobile No</label>
                            <input type="number" class="form-control" id="mono" name="mono" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;"  value="{{$user->mono}}">
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="mb-3 mt-3">
                            <label for="exampleFormControlInput1" class="form-label">Gender</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" id="male" value="Male" {{ $user->gender == 'Male' ? 'checked':''}}>
                                <label class="form-check-label" for="flexRadioDefault1">  Male </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="female" value="Female" {{ $user->gender == 'Female' ? 'checked':''}}>
                                    <label class="form-check-label" for="flexRadioDefault2">Female</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="submit" class="btn btn-success">Update</button>
                </div>
            </form>
            <form action="{{ url('password_update/'.$user->id) }}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="tab-pane fade" id="profile-tab-pane" role="tabpanel" aria-labelledby="profile-tab" tabindex="0">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="mb-3 mt-3">
                                <label for="exampleFormControlInput1" class="form-label">Password</label>
                                <input type="password" class="form-control @error('password') is-invalid @enderror" id="password" name="password">
                            </div>
                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-sm-3">
                            <div class="mb-3 mt-3">
                                <label for="exampleFormControlInput1" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control @error('password') is-invalid @enderror" id="password_confirmation" name="password_confirmation">
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="submit" class="btn btn-success">Change Password</button>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="editimgModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Profile Image</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
            <form action="{{ url('profile_image/'.$user->id) }}" method="post" enctype="multipart/form-data">
              @csrf
            <input type="file" class="form-control" id="profile_image" name="profile_image" placeholder="" style="color:#000 !important">
            <button type="submit" name="submit" class="btn btn-primary mt-3">Save changes</button>
            <button type="button" class="btn btn-secondary mt-3" data-bs-dismiss="modal">Close</button>
        </form>
        </div>
        {{-- <div class="modal-footer">
          <button type="submit" name="submit" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div> --}}
      </div>
    </div>
  </div>
@endsection
