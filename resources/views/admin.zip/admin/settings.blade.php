@extends('admin.layouts.app')

@section('content')
<div class="card mb-5 mb-xl-10">
    <!--begin::Card header-->
    <div class="card-header border-0 cursor-pointer" role="button" data-bs-toggle="collapse" data-bs-target="#kt_account_profile_details" aria-expanded="true" aria-controls="kt_account_profile_details">
        <!--begin::Card title-->
        <div class="card-title m-0">
            <h3 class="fw-bold m-0">Profile Details</h3>
        </div>
        <!--end::Card title-->
    </div>
    <!--begin::Card header-->
    <!--begin::Content-->
    <div id="kt_account_settings_profile_details" class="collapse show">
        <!--begin::Form-->

            <!--begin::Card body-->
            <div class="card-body border-top p-9">
                <!--begin::Input group-->
                <div class="row mb-6">
                    <!--begin::Label-->
                    <label class="col-lg-4 col-form-label fw-semibold fs-6">{{ucfirst($admin->name)}}</label>
                    <!--end::Label-->
                    <!--begin::Col-->
                    <div class="col-lg-8">
                        <!--begin::Image input-->
                        <div class="image-input image-input-outline" data-kt-image-input="true" style="background-image: url('{{ asset('user_image/'.$admin->profile_image) }}')">
                            <!--begin::Preview existing avatar-->
                            <div class="image-input-wrapper w-125px h-125px" style="background-image: url({{ asset('user_image/'.$admin->profile_image) }})"></div>
                            <!--end::Preview existing avatar-->
                            <!--begin::Label-->

                            <form action="{{ url('adminprofile_image/'.$admin->id) }}" method="post" enctype="multipart/form-data">
                                @csrf
                              <input type="file"  id="profile_image" name="profile_image" placeholder="" style="color:#000 !important">
                              <button type="submit" name="submit" class="btn btn-icon btn-circle btn-active-color-primary w-35px h-35px bg-body shadow"><i class="fa-regular fa-pen-to-square"></i></button>
                              <button type="button" class="btn btn-icon btn-circle btn-active-color-danger w-35px h-35px bg-body shadow" data-bs-dismiss="modal"><i class="fa-solid fa-x"></i></button>
                          </form>
                            <!--end::Remove-->
                        </div>
                        <!--end::Image input-->
                        <!--begin::Hint-->
                        <div class="form-text">Allowed file types: png, jpg, jpeg.</div>
                        <!--end::Hint-->
                    </div>
                    <!--end::Col-->
                </div>
                <form action="{{ url('adminprofile_update/'.$admin->id) }}" method="post" enctype="multipart/form-data">
                    @csrf
                <!--end::Input group-->
                <!--begin::Input group-->
                <div class="row mb-6">
                    <label class="col-lg-4 col-form-label required fw-semibold fs-6">Full Name</label>
                    <div class="col-lg-8">
                        <div class="row">
                            <div class="col-lg-12 fv-row">
                                <input type="text" name="name" id="name" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" placeholder="First name" value="{{$admin->name}}" />
                                <span class="text-danger">@error('name'){{$message}}@enderror</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mb-6">
                    <label class="col-lg-4 col-form-label required fw-semibold fs-6">Email</label>
                    <div class="col-lg-8">
                        <div class="row">
                            <div class="col-lg-12 fv-row">
                                <input type="email" name="email" mono class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" placeholder="First name" value="{{$admin->email}}" />
                                <span class="text-danger">@error('email'){{$message}}@enderror</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-6">
                    <label class="col-lg-4 col-form-label required fw-semibold fs-6">Mobile No</label>
                    <div class="col-lg-8">
                        <div class="row">
                            <div class="col-lg-12 fv-row">
                                <input type="number" name="mono" id="mono" class="form-control form-control-lg form-control-solid mb-3 mb-lg-0" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;" placeholder="First name" value="{{$admin->mono}}" />
                                <span class="text-danger">@error('mono'){{$message}}@enderror</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-6">
                    <label class="col-lg-4 col-form-label required fw-semibold fs-6">Gender</label>
                    <div class="col-lg-8">
                        <div class="row">
                            <div class="col-lg-12 fv-row">
                                <div class="form-check pb-4">
                                    <input class="form-check-input" type="radio" name="gender" id="male" value="Male" {{ $admin->gender == 'Male' ? 'checked':''}}>
                                    <label class="form-check-label" for="flexRadioDefault1">  Male </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="female" value="Female" {{ $admin->gender == 'Female' ? 'checked':''}}>
                                    <label class="form-check-label" for="flexRadioDefault2">Female</label>
                                </div>
                                <span class="text-danger">@error('gender'){{$message}}@enderror</span>
                            </div>
                        </div>
                    </div>
                </div>
            <!--end::Card body-->
            <!--begin::Actions-->
            <div class="card-footer d-flex justify-content-end py-6 px-9">
                <button type="reset" class="btn btn-light btn-active-light-primary me-2">Discard</button>
                <button type="submit" class="btn btn-primary" id="kt_account_profile_details_submit">Save Changes</button>
            </div>
            <!--end::Actions-->
        </form>
        <!--end::Form-->
    </div>
    <!--end::Content-->
</div>
@endsection
